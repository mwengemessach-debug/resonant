export async function decodeAudio(fileOrUrl) {
  const data = fileOrUrl instanceof File ? await fileOrUrl.arrayBuffer() : await (await fetch(fileOrUrl)).arrayBuffer();
  const context = new AudioContext();
  try { return await context.decodeAudioData(data.slice(0)); } finally { await context.close(); }
}

export function analyzeBuffer(buffer) {
  const channels = Array.from({length:buffer.numberOfChannels},(_,i)=>buffer.getChannelData(i));
  let sum=0, peak=0, clipped=0, count=0, side=0, mid=0, zc=0;
  const stride=Math.max(1,Math.floor(buffer.length/1_500_000));
  for(let i=0;i<buffer.length;i+=stride){
    const l=channels[0][i]||0, r=(channels[1]||channels[0])[i]||0;
    sum+=(l*l+r*r)/2; peak=Math.max(peak,Math.abs(l),Math.abs(r)); if(Math.abs(l)>.999||Math.abs(r)>.999)clipped++;
    mid+=Math.abs((l+r)/2); side+=Math.abs((l-r)/2); if(i>0&&Math.sign(l)!==Math.sign(channels[0][Math.max(0,i-stride)]))zc++; count++;
  }
  const rms=Math.sqrt(sum/count); const db=v=>20*Math.log10(Math.max(v,1e-9));
  return {
    duration:buffer.duration, sampleRate:buffer.sampleRate, channels:buffer.numberOfChannels,
    peakDb:Number(db(peak).toFixed(1)), rmsDb:Number(db(rms).toFixed(1)),
    crestDb:Number((db(peak)-db(rms)).toFixed(1)), clipping:Number((clipped/count*100).toFixed(3)),
    stereoWidth:Number(Math.min(100,side/Math.max(mid,1e-6)*100).toFixed(0)),
    brightness:Number(Math.min(100,(zc/count)*650).toFixed(0))
  };
}

export function makeReport(m) {
  return [
    {label:'True peak proxy',value:`${m.peakDb} dBFS`,score:m.peakDb<=-0.8?92:m.peakDb<=-0.1?70:35,note:m.peakDb>-0.1?'Peak samples risk inter-sample clipping.':'Healthy peak margin.'},
    {label:'Dynamics',value:`${m.crestDb} dB crest`,score:m.crestDb>=7&&m.crestDb<=18?90:65,note:m.crestDb<7?'Dense; avoid aggressive limiting.':m.crestDb>18?'Wide dynamics; gentle control may help.':'Natural macro-dynamics.'},
    {label:'Clipping',value:`${m.clipping}%`,score:m.clipping===0?98:Math.max(10,90-m.clipping*100),note:m.clipping?'Clipped samples detected.':'No clipped samples detected.'},
    {label:'Stereo width',value:`${m.stereoWidth}%`,score:m.stereoWidth<85?88:65,note:m.stereoWidth>85?'Very wide; check mono compatibility.':'Width is within a conservative range.'},
    {label:'Brightness proxy',value:`${m.brightness}/100`,score:m.brightness>8&&m.brightness<75?84:65,note:'Zero-crossing proxy, not a spectral verdict.'}
  ];
}

export async function renderMaster(buffer, settings) {
  const ctx=new OfflineAudioContext(buffer.numberOfChannels,buffer.length,buffer.sampleRate);
  const source=ctx.createBufferSource(); source.buffer=buffer;
  const low=ctx.createBiquadFilter(); low.type='lowshelf'; low.frequency.value=120; low.gain.value=settings.low;
  const presence=ctx.createBiquadFilter(); presence.type='peaking'; presence.frequency.value=3000; presence.Q.value=.7; presence.gain.value=settings.presence;
  const comp=ctx.createDynamicsCompressor(); comp.threshold.value=settings.threshold; comp.knee.value=12; comp.ratio.value=settings.ratio; comp.attack.value=.02; comp.release.value=.25;
  const gain=ctx.createGain(); gain.gain.value=Math.pow(10,settings.gain/20);
  source.connect(low).connect(presence).connect(comp).connect(gain).connect(ctx.destination); source.start(); return ctx.startRendering();
}

export function bufferToWav(buffer) {
  const ch=buffer.numberOfChannels, len=buffer.length*ch*2+44, out=new ArrayBuffer(len), view=new DataView(out); let pos=0;
  const str=s=>{for(let i=0;i<s.length;i++)view.setUint8(pos++,s.charCodeAt(i))}; const u32=v=>{view.setUint32(pos,v,true);pos+=4}; const u16=v=>{view.setUint16(pos,v,true);pos+=2};
  str('RIFF');u32(len-8);str('WAVE');str('fmt ');u32(16);u16(1);u16(ch);u32(buffer.sampleRate);u32(buffer.sampleRate*ch*2);u16(ch*2);u16(16);str('data');u32(len-44);
  const channels=Array.from({length:ch},(_,i)=>buffer.getChannelData(i)); for(let i=0;i<buffer.length;i++)for(let c=0;c<ch;c++){const s=Math.max(-1,Math.min(1,channels[c][i]));view.setInt16(pos,s<0?s*0x8000:s*0x7fff,true);pos+=2}
  return new Blob([out],{type:'audio/wav'});
}

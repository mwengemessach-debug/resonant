import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs/promises';
import fsSync from 'fs';
import crypto from 'crypto';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { fileURLToPath, pathToFileURL } from 'url';
import { buildProductionPlan, makeTrebloPayload, statusProgress } from './producer.js';
import { allEngineHealth, submitEngine, pollEngine, allowedEngineUrl } from './engines.js';
import { brainStatus, buildBrainPlan } from './gemini.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const PORT = Number(process.env.PORT) || 8787;
const BASE = process.env.TREBLO_BASE_URL || 'https://api.treblo.com/v1';
const key = process.env.TREBLO_API_KEY || '';
const runtimeRoot = process.env.VERCEL ? '/tmp/resonant' : root;
const audioDir = path.resolve(runtimeRoot, process.env.AUDIO_DIR || 'data/audio');
const projectDir = path.resolve(runtimeRoot, 'data/projects');
const uploadDir = path.resolve(runtimeRoot, 'data/uploads');
const execFileAsync = promisify(execFile);
await fs.mkdir(audioDir, { recursive: true }); await fs.mkdir(projectDir, { recursive: true }); await fs.mkdir(uploadDir, { recursive: true });

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use('/audio', express.static(audioDir, { fallthrough: false, immutable: false, maxAge: '1h' }));
const upload = multer({ dest: uploadDir, limits: { fileSize: 40 * 1024 * 1024 }, fileFilter: (_r, f, cb) => cb(null, /audio\/(mpeg|mp4|ogg|flac|wav|x-wav|aac|aiff)/.test(f.mimetype) || /\.(mp3|m4a|ogg|flac|wav|amr|aac|aiff)$/i.test(f.originalname)) });

function auth() { return { Authorization: `Bearer ${key}` }; }
async function trebo(url, options = {}) {
  if (!key) { const e = new Error('Treblo is not connected. Add TREBLO_API_KEY on the server.'); e.status = 503; throw e; }
  const response = await fetch(`${BASE}${url}`, { ...options, headers: { ...auth(), ...(options.headers || {}) }, signal: AbortSignal.timeout(options.timeout || 30000) });
  const text = await response.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  if (!response.ok) { const e = new Error(data?.detail || data?.message || `Treblo returned ${response.status}`); e.status = response.status; e.details = data; throw e; }
  return data;
}

const ensembleSessions = new Map();
async function persistEngineAudio(sourceUrl, engine) {
  if (!allowedEngineUrl(sourceUrl)) throw new Error('Engine returned an untrusted audio URL.');
  const response=await fetch(sourceUrl,{signal:AbortSignal.timeout(180000)});if(!response.ok)throw new Error(`${engine} audio download failed (${response.status})`);
  const contentType=response.headers.get('content-type')||'';const guessed=contentType.includes('flac')?'.flac':contentType.includes('mpeg')?'.mp3':contentType.includes('ogg')?'.ogg':'.wav';
  const name=`${Date.now()}-${engine}-${crypto.randomUUID()}${guessed}`;await fs.writeFile(path.join(audioDir,name),Buffer.from(await response.arrayBuffer()));return `/audio/${name}`;
}

app.get('/api/config', async (_req, res) => {
  const base = { connected: false, verified: false, credits: null, ffmpeg: false, provider: 'Treblo Melodia v3', pricingChecked: '2026-10-26', costPerGeneration: 100 };
  try { base.ffmpeg = Boolean(fsSync.existsSync('/usr/bin/ffmpeg') || fsSync.existsSync('/usr/local/bin/ffmpeg')); if (key) { const credits = await trebo('/credits/balance'); Object.assign(base, { connected: true, verified: true, credits }); } } catch (e) { base.connected = Boolean(key); base.error = e.message; }
  res.json(base);
});

app.get('/api/brain/status',(_req,res)=>res.json(brainStatus()));
app.post('/api/plan', async (req, res, next) => { try{res.json(await buildBrainPlan(req.body))}catch(e){next(e)} });

app.get('/api/engines', async (_req,res)=>res.json(await allEngineHealth()));
app.post('/api/ensemble/generate', async (req,res,next)=>{
  try{
    const plan=await buildBrainPlan(req.body);const engines=(await allEngineHealth()).filter(x=>x.available && (req.body.allowNonCommercial || x.commercial));
    if(!engines.length)return res.status(503).json({error:'No compatible local generation engine is running. Start ACE-Step, YuE, or MusicGen first.'});
    const id=crypto.randomUUID();const candidates=await Promise.all(engines.map(async engine=>{try{const x=await submitEngine(engine.id,plan);return {engine:engine.id,name:engine.name,license:engine.license,commercial:engine.commercial,status:'queued',progress:8,taskId:x.taskId}}catch(e){return {engine:engine.id,name:engine.name,license:engine.license,commercial:engine.commercial,status:'failed',progress:100,error:e.message}}}));
    const session={id,createdAt:new Date().toISOString(),plan,candidates};ensembleSessions.set(id,session);res.status(202).json(session);
  }catch(e){next(e)}
});
app.get('/api/ensemble/status/:id',async(req,res,next)=>{
  try{const session=ensembleSessions.get(req.params.id);if(!session)return res.status(404).json({error:'Ensemble session not found.'});
    await Promise.all(session.candidates.map(async c=>{if(['succeeded','failed'].includes(c.status))return;try{Object.assign(c,await pollEngine(c.engine,c.taskId));if(c.status==='succeeded'&&c.audioUrl&&!c.localUrl)c.localUrl=await persistEngineAudio(c.audioUrl,c.engine)}catch(e){c.error=e.message;c.status='failed';c.progress=100}}));
    const done=session.candidates.every(c=>['succeeded','failed'].includes(c.status));res.json({...session,done});
  }catch(e){next(e)}
});

app.post('/api/upload-reference', upload.single('file'), async (req, res, next) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a supported audio file up to 40 MB.' });
  try {
    const form = new FormData(); const bytes = await fs.readFile(req.file.path);
    form.append('file', new Blob([bytes], { type: req.file.mimetype }), req.file.originalname);
    const data = await trebo('/uploads', { method: 'POST', body: form, timeout: 60000 });
    await fs.unlink(req.file.path).catch(() => {}); res.json(data);
  } catch (e) { await fs.unlink(req.file.path).catch(() => {}); next(e); }
});

app.post('/api/generate', async (req, res, next) => {
  try {
    const plan = await buildBrainPlan(req.body); const payload = makeTrebloPayload(plan, req.body);
    const endpoint = plan.mode === 'reference' ? '/generations/v3/reference' : '/generations/v3';
    const result = await trebo(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), timeout: 45000 });
    res.status(202).json({ ...result, plan, endpoint });
  } catch (e) { next(e); }
});

app.post('/api/extend', async (req, res, next) => { try { const body = { audio_url:req.body.audioUrl, prompt:String(req.body.prompt||'Continue naturally with a resolved ending').slice(0,1200), context_seconds:Math.min(284,Math.max(1,Number(req.body.contextSeconds)||45)), crop_duration:Math.max(0,Number(req.body.cropDuration)||0), output_format:'wav', enable_streaming:true }; res.status(202).json(await trebo('/generations/v3/extend',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})); } catch(e){next(e)} });
app.post('/api/inpaint', async (req, res, next) => { try { const start=Number(req.body.start), end=Number(req.body.end); if (!(end>start)) return res.status(400).json({error:'Section end must be after start.'}); const body={audio_url:req.body.audioUrl,prompt:String(req.body.prompt||'Improve this section').slice(0,1200),lyrics:String(req.body.lyrics||''),sections:[[start,end]],selection_crop:false,output_format:'wav'}; res.status(202).json(await trebo('/generations/v2/inpaint',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})); }catch(e){next(e)} });

app.get('/api/status/:id', async (req, res, next) => { try { const status = await trebo(`/generations/status/${encodeURIComponent(req.params.id)}?include_alignment=true`); const name = typeof status === 'string' ? status : status.status; res.json({ ...(typeof status === 'object' ? status : {status:name}), progress:statusProgress(name), streamReady:name==='GENERATING_STREAMING_READY', streamUrl:`https://api-stream.treblo.com/stream/${encodeURIComponent(req.params.id)}` }); } catch(e){next(e)} });
app.get('/api/result/:id', async (req, res, next) => { try { res.json(await trebo(`/generations/${encodeURIComponent(req.params.id)}`)); } catch(e){next(e)} });

app.post('/api/persist', async (req, res, next) => {
  try {
    const url = new URL(req.body.url); if (!/(^|\.)treblo\.com$/i.test(url.hostname)) return res.status(400).json({error:'Only Treblo result URLs can be persisted.'});
    const response = await fetch(url, { signal: AbortSignal.timeout(120000) }); if (!response.ok) throw new Error(`Audio download failed (${response.status})`);
    const ext = (path.extname(url.pathname).match(/^\.[a-z0-9]{2,5}$/i)||['.wav'])[0]; const name=`${Date.now()}-${crypto.randomUUID()}${ext}`; await fs.writeFile(path.join(audioDir,name),Buffer.from(await response.arrayBuffer()));
    res.json({url:`/audio/${name}`,filename:name,persisted:true});
  } catch(e){next(e)}
});

const memoryUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 80 * 1024 * 1024 } });
app.post('/api/export/:format', memoryUpload.single('file'), async (req, res, next) => {
  const format = String(req.params.format).toLowerCase();
  if (!['mp3','flac','wav'].includes(format)) return res.status(400).json({error:'Format must be WAV, FLAC, or MP3.'});
  if (!req.file) return res.status(400).json({error:'No rendered audio was supplied.'});
  const ffmpeg = fsSync.existsSync('/usr/bin/ffmpeg') ? '/usr/bin/ffmpeg' : fsSync.existsSync('/usr/local/bin/ffmpeg') ? '/usr/local/bin/ffmpeg' : null;
  if (!ffmpeg) return res.status(503).json({error:'FFmpeg is not installed. WAV export remains available locally.'});
  const id=crypto.randomUUID(), input=path.join(audioDir,`${id}-input.wav`), output=path.join(audioDir,`${id}.${format}`);
  try { await fs.writeFile(input,req.file.buffer); const codec=format==='mp3'?['-codec:a','libmp3lame','-b:a','320k']:format==='flac'?['-codec:a','flac']:['-codec:a','pcm_s24le']; await execFileAsync(ffmpeg,['-y','-i',input,...codec,output],{timeout:120000}); res.download(output,`resonant-master.${format}`,async()=>{await fs.unlink(input).catch(()=>{});await fs.unlink(output).catch(()=>{})}); } catch(e){await fs.unlink(input).catch(()=>{});await fs.unlink(output).catch(()=>{});next(e)}
});

app.get('/api/projects', async (_req,res)=>{ const files=(await fs.readdir(projectDir)).filter(x=>x.endsWith('.json')); const projects=await Promise.all(files.map(async f=>JSON.parse(await fs.readFile(path.join(projectDir,f),'utf8')))); res.json(projects.sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)))); });
app.put('/api/projects/:id', async(req,res)=>{ const id=String(req.params.id).replace(/[^a-z0-9-]/gi,''); if(!id)return res.status(400).json({error:'Invalid id'}); const project={...req.body,id,updatedAt:new Date().toISOString()}; await fs.writeFile(path.join(projectDir,`${id}.json`),JSON.stringify(project,null,2)); res.json(project); });

app.use((err,_req,res,_next)=>{ console.error(err); res.status(err.status||500).json({error:err.message||'Unexpected server error',details:err.details||undefined}); });
if (process.env.NODE_ENV === 'production' && !process.env.VERCEL) { app.use(express.static(path.join(root,'dist'))); app.get('*',(_r,res)=>res.sendFile(path.join(root,'dist','index.html'))); }
const isDirect = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isDirect) app.listen(PORT,'0.0.0.0',()=>console.log(`Resonant server listening on 0.0.0.0:${PORT}`));
export default app;
